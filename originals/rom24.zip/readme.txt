ROM for Windows
===============

This version ported to 32-bit Windows by Nick Gammon

Email:  nick@gammon.com.au

29th January 1999

-----------------------------------------
If you are reading this file with NotePad,
enable "Word Wrap" under the Edit menu for
proper viewing of it.
-----------------------------------------

Bug fix in this version
-----------------------

A problem with saving player files has been fixed.


Unzipping
---------

Make sure you have unzipped all files with the original folder names. In WinZip this is the "Use folder names" option, otherwise it certainly won't work!

I suggest creating a directory called ROM into which will be placed all of the appropriate files, and then unzipping into that directory.

Running ROM
-------------

Just open a DOS window, go to the ROM directory, and type:

ROM <port>

You should see a whole lot of things scroll by, like this:

----------------------------------------
Working directory now C:\rom\area
Thu Nov 19 09:54:08 1998 :: [*****] BUG: Fix_exits: 10525:1 -> 10535:3 -> 10534.

Thu Nov 19 09:54:08 1998 :: [*****] BUG: Fix_exits: 3458:2 -> 3472:0 -> 10401.
Thu Nov 19 09:54:08 1998 :: [*****] BUG: Fix_exits: 8705:4 -> 8706:5 -> 8708.
Thu Nov 19 09:54:08 1998 :: [*****] BUG: Fix_exits: 8717:2 -> 8719:0 -> 8718.
Err: obj an icicle (9227) -- 28, mob the Ice Bandit (9228) -- 24
Err: obj elemental wand of wind and air (9218) -- 27, mob an alchemist (9234) --
 13
Err: obj an ice staff (9216) -- 25, mob a baby rainbow dragon (9235) -- 16
Err: obj an ice staff (9216) -- 25, mob a puddle (9214) -- 8
Err: obj elemental wand of fire (9215) -- 16, mob a flame (9215) -- 4
Err: obj elemental wand of fire (9215) -- 16, mob a flame (9215) -- 4
Err: obj an elemental rod of earthquake (9217) -- 7, mob a small rock (9217) --
3
Err: obj elemental wand of wind and air (9218) -- 27, mob a small spark (9218) -
- 4
Err: obj elemental wand of wind and air (9218) -- 27, mob an eddie (9225) -- 2
Err: obj a wet noodle (8010) -- 5, mob a Futsie (8002) -- 17
Thu Nov 19 09:54:08 1998 :: ROM is ready to rock on port 4000.
----------------------------------------



You can now connect to ROM using your client program. I suggest using MUSHclient, available from:

http://www.gammon.com.au/mushclient/mushclient.htm


For testing purposes, however, you can use Telnet, that comes with Windows.


To connect to your local PC (ie. not going through the Internet), connect to:

127.0.0.1  port 4000



Credits for ROM
---------------

ROM 2.4 beta is copyright 1993 - 1996 by Russ Taylor <rtaylor@efn.org>.

You can find the source code for ROM, and more about it at: http://www.cmc.net/~rtaylor/

Further documentation about ROM and its licence agreements is in the "doc" subdirectory.



Pre-supplied player
-------------------

To help you get started (ie. so you can shut down the MUD) there is a player supplied as part of the archive:

Name: Lordrom
Password: win95

To shut down the MUD, you can log on as Lordrom, and then type: shutdown mud now

To see wizard commands, type: wizhelp


Area Editor
-----------------
 
I have developed a GUI (graphical interface) area editor, specifically designed for use with SMAUG and ROM areas. Many details, including descriptions and screen dumps are available at:

	http://www.gammon.com.au/smaugeditor/smaugeditor.htm

Briefly, you can:

You can:

1. Set attributes for rooms, mobiles etc. using checkboxes, rather than having to add up large numbers.
2. Add, delete or duplicate things in the area. Deleting an item (eg. a room) optionally deletes references to that item (eg. exits leading to the room). Duplicating an item (eg. an object) also duplicates sub-items (eg. programs, affects etc.)
3. Syntax-check MUD programs against your current commands/skills/socials files
4. Do an "area check" to check for missing, or unused, items
5. Renumber the vnums in an area, including references to vnums in MUD programs
6. Cross-reference most things against each other (eg. which mobs are loaded into a particular room)
7. Find things by summary, detail, program contents, or vnum.
8. View commands/skills/socials in an easy-to-view window.
9. Print an area to give a hard-copy summary of what all rooms/mobs/objects are.
10. Specify flag names as used in your particular version of the MUD code-base.
11. Do an "area walkthrough" which simulates what you would see as you enter each room in the area.
12. Export an area as MUSH code.
13. Read SMAUG or ROM areas, and convert from one to the other if desired.



Queries
-------

If you have problems with the Windows version of ROM, write to:

Nick Gammon <nick@gammon.com.au>

Otherwise, see:

http://www.cmc.net/~rtaylor/

which is the site of the original version of ROM, including the source code.




